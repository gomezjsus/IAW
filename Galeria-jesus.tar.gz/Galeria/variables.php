<?php
    $dir="galeria/";
?>

