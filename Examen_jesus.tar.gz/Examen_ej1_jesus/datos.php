<?php
$viviendas=array( 
    "77231819Z"=>array("dir"=>"C/Miguel Hernández","nro"=>5,"cdp"=>"30011"), 
    "22776122A"=>array("dir"=>"C/Mayor","nro"=>15,"cdp"=>"30008"), 
    "44212861W"=>array("dir"=>"C/Miguel Hernández","nro"=>3,"cdp"=>"30011"), 
    "39671773B"=>array("dir"=>"C/Saavedra Fajardo","nro"=>10,"cdp"=>"30017") 
); 
?>